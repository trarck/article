apps = [
['com.myyearbook.m','MeetMe: Chat & Meet New People','Social','http://www.meetme.com','https://play.google.com/store/apps/details?id=com.myyearbook.m','http://playboard.me/android/apps/air.com.games2win.bffhsfashion'], 
['com.taggedapp','Tagged - Meet, Chat & Date','Social','http://tagged.com','https://play.google.com/store/apps/details?id=com.taggedapp','http://playboard.me/android/apps/air.com.games2win.bffhsfashion'], ['com.enflick.android.TextNow','TextNow','Social','http://textnow.com','https://play.google.com/store/apps/details?id=com.enflick.android.TextNow','http://playboard.me/android/apps/air.com.games2win.bffhsfashion'],
['com.onelouder.baconreader','BaconReader for Reddit','Social','http://onelouder.com','https://play.google.com/store/apps/details?id=com.onelouder.baconreader','http://playboard.me/android/apps/air.com.games2win.bffhsfashion'],
['com.tapinator.cartransporter.truck3d','3D Car Transport Trailer Free','Social','http://tapinator.com','https://play.google.com/store/apps/details?id=com.tapinator.cartransporter.truck3d','http://playboard.me/android/apps/air.com.games2win.bffhsfashion'],
['com.games2win.parkingfrenzy','Parking Frenzy 2.0','Social','http://games2win.com','https://play.google.com/store/apps/details?id=com.games2win.parkingfrenzy','http://playboard.me/android/apps/air.com.games2win.bffhsfashion'],
['com.cleanmaster.mguard','Clean Master (Boost & AppLock)','Social','http://www.cmcm.com/','https://play.google.com/store/apps/details?id=com.cleanmaster.mguard&hl=en','http://playboard.me/android/apps/air.com.games2win.bffhsfashion'],
['com.ea.gp.bej3','Bejeweled Classic','Social','http://www.eamobile.com/','https://play.google.com/store/apps/details?id=com.ea.gp.bej3','http://playboard.me/android/apps/air.com.games2win.bffhsfashion']
];

/*
bundle =  0
appname = 1
cat =     2
domain =  3
store =   4
*/
function setSize(size) {
	switch(size) {
		case 300:
			h=320;
			w=480;
			imgSz="300x250";
			break;
		case 728:
			h=480;
			w=730;
			imgSz="728x90";
			break;
		case 160:
			h=600;
			w=900;
			imgSz="160x600";
			break;
		case 320:
			h=320;
			w=480;
			imgSz="320x50";
	}
}
xTest = true;
function createGuid()
	{
	    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
	        var r = Math.random()*16|0, v = c === 'x' ? r : (r&0x3|0x8);
	        return v.toString(16);
	    });
	}
	var appGuid = createGuid();
	var sameApp = 0;
	function whichApp(){
		sameApp = Math.floor(Math.random() * apps.length);
		return sameApp;
	}
	function rUserAgent(){
		return userAgent[Math.floor(Math.random() * userAgent.length)];
	}
	
	function setUserAgent(window, userAgent) {
    if (window.navigator.userAgent != userAgent) {
        var userAgentProp = { get: function () { return userAgent; } };
        try {
            Object.defineProperty(window.navigator, 'userAgent', userAgentProp);
        } catch (e) {
            window.navigator = Object.create(navigator, {
                userAgent: userAgentProp
            });
        }
    }
}

function randNum() {
	var getRandomNum = Math.random() + "";
	var randomNum = getRandomNum * 10000000000000;
	return(randomNum);
	}

function randINT(min,max)
{
    return Math.floor(Math.random()*(max-min+1)+min);
}
function VAST() {
	whichAdTag = randINT(1, 12);
	var sameUserAgent = encodeURI(rUserAgent());
	setUserAgent(window, sameUserAgent);
	whichApp();
	thisAppName = encodeURIComponent(apps[sameApp][1]);
	thisAppStoreURL = encodeURIComponent(apps[sameApp][4]);
	thisAppBundle = encodeURIComponent(apps[sameApp][0]);
	thisAppDomain = encodeURIComponent(apps[sameApp][3]);
	if(whichAdTag == 1) {
	//aol high
		var newVAST  = 'http://ads.adaptv.advertising.com/a/h/wCLx0DphyzD4Ek6FjFWOtbPew0RBByrF0TijDY4n9I6g63SWosWzAw==?cb=' + randNum() + '&app_bundle=' + thisAppBundle + '&app_storeurl=' + thisAppStoreURL + '&appName=' + thisAppName + '&a.ua=' + sameUserAgent+ '&a.aid=' + appGuid + '&eov=eov';
		}
		else if(whichAdTag == 2) {
		//perktv
			var newVAST = 'http://serve.vdopia.com/adserver/html5/inwapads/?ak=959381101682b1802c85e7fd7c7fab72&category=IAB1-7&type=app&adFormat=preappvideo&sleepAfter=0&version=1.1&requester=revolution&appName=perktv&appBundle=com.juteralabs.perktv&appDomain=perktv.com&appStoreURL=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.juteralabs.perktv&dif=dpid&size=480x320&dnt=0&output=vast&cb=' + randNum() + '&di=' + appGuid + '&ua=' + sameUserAgent;
		}
		else if(whichAdTag == 3) {
		//perktv
			var newVAST = 'http://serve.vdopia.com/adserver/html5/inwapads/?ak=959381101682b1802c85e7fd7c7fab72&category=IAB1-7&type=app&adFormat=preappvideo&sleepAfter=0&version=1.1&requester=revolution&appName=perktv&appBundle=com.juteralabs.perktv&appDomain=perktv.com&appStoreURL=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.juteralabs.perktv&dif=dpid&size=480x320&dnt=0&output=vast&cb=' + randNum() + '&di=' + appGuid + '&ua=' + sameUserAgent;
		}
		else if(whichAdTag == 4) {
		//perktv
			var newVAST = 'http://serve.vdopia.com/adserver/html5/inwapads/?ak=959381101682b1802c85e7fd7c7fab72&category=IAB1-7&type=app&adFormat=preappvideo&sleepAfter=0&version=1.1&requester=revolution&appName=perktv&appBundle=com.juteralabs.perktv&appDomain=perktv.com&appStoreURL=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.juteralabs.perktv&dif=dpid&size=480x320&dnt=0&output=vast&cb=' + randNum() + '&di=' + appGuid + '&ua=' + sameUserAgent;
		}
		else if(whichAdTag == 5) {
		//tweetcaster
			var newVAST = 'http://serve.vdopia.com/adserver/html5/inwapads/?ak=274aa1044281edfaf8d1370241ddc76e&type=app&adFormat=preappvideo&sleepAfter=0&version=1.1&requester=revolution&appName=TweetCaster%20for%20Twitter&appBundle=com.handmark.tweetcaster&appDomain=onelouder.com&appStoreURL=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.handmark.tweetcaster&dif=dpid&size=480x320&dnt=0&output=vast&cb=' + randNum() + '&di=' + appGuid + '&ua=' + sameUserAgent;
		}
		else if(whichAdTag == 6) {
		//tweetcaster
			var newVAST = 'http://serve.vdopia.com/adserver/html5/inwapads/?ak=274aa1044281edfaf8d1370241ddc76e&type=app&adFormat=preappvideo&sleepAfter=0&version=1.1&requester=revolution&appName=TweetCaster%20for%20Twitter&appBundle=com.handmark.tweetcaster&appDomain=onelouder.com&appStoreURL=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.handmark.tweetcaster&dif=dpid&size=480x320&dnt=0&output=vast&cb=' + randNum() + '&di=' + appGuid + '&ua=' + sameUserAgent;
		}
		else if(whichAdTag == 7) {
		//bejewled
			var newVAST = 'http://serve.vdopia.com/adserver/html5/inwapads/?ak=ede9c82981959ec1b00da31115a177d5&category=IAB9&type=app&adFormat=preappvideo&sleepAfter=0&version=1.1&requester=revolution&appName=Bejeweled%20Classic&appBundle=com.ea.gp.bej3&appDomain=eamobile.com&appStoreURL=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.ea.gp.bej3&dif=dpid&size=480x320&dnt=0&output=vast&cb=' + randNum() + '&di=' + appGuid + '&ua=' + sameUserAgent;
		}
		else if(whichAdTag == 8) {
		//bejewled
			var newVAST = 'http://serve.vdopia.com/adserver/html5/inwapads/?ak=ede9c82981959ec1b00da31115a177d5&category=IAB9&type=app&adFormat=preappvideo&sleepAfter=0&version=1.1&requester=revolution&appName=Bejeweled%20Classic&appBundle=com.ea.gp.bej3&appDomain=eamobile.com&appStoreURL=https%3A%2F%2Fplay.google.com%2Fstore%2Fapps%2Fdetails%3Fid%3Dcom.ea.gp.bej3&dif=dpid&size=480x320&dnt=0&output=vast&cb=' + randNum() + '&di=' + appGuid + '&ua=' + sameUserAgent;
		}
		else if(whichAdTag == 9) {
		//all
			var newVAST = 'http://serve.vdopia.com/adserver/html5/inwapads/?ak=11d50f44802808c33a7e579688d6e374&type=app&adFormat=preappvideo&sleepAfter=0&version=1.1&requester=revolution&appName=' + thisAppName + '&appBundle=' + thisAppBundle + '&appDomain=' + thisAppDomain + '&appStoreURL=' + thisAppStoreURL + '&dif=dpid&size=480x320&dnt=0&output=vast&cb=' + randNum() + '&di=' + appGuid + '&ua=' + sameUserAgent;
		}
		else if(whichAdTag == 10) {
		//VDMW Android
			var newVAST = 'http://serve.vdopia.com/adserver/html5/inwapads/?sleepAfter=0&adFormat=preappvideo&ak=JKBEup&version=1.1&channelType=site&output=vast&pageURL=' + pageURL + '&siteName=' + pageURL + '&requester=revolutionmobile&refURL=' + pageURL + '&ua= ' + sameUserAgent + '&size=720x480&domain=' + pageURL + '&cb=' + randNum(); 
		}
		else if(whichAdTag == 11) {
		//VDMW Android
			var newVAST = 'http://serve.vdopia.com/adserver/html5/inwapads/?sleepAfter=0&adFormat=preappvideo&ak=JKBEup&version=1.1&channelType=site&output=vast&pageURL=' + pageURL + '&siteName=' + pageURL + '&requester=revolutionmobile&refURL=' + pageURL + '&ua= ' + sameUserAgent + '&size=720x480&domain=' + pageURL + '&cb=' + randNum(); 
		}
		else if(whichAdTag == 12) {
		//VDMW Android
			var newVAST = 'http://serve.vdopia.com/adserver/html5/inwapads/?sleepAfter=0&adFormat=preappvideo&ak=JKBEup&version=1.1&channelType=site&output=vast&pageURL=' + pageURL + '&siteName=' + pageURL + '&requester=revolutionmobile&refURL=' + pageURL + '&ua= ' + sameUserAgent + '&size=720x480&domain=' + pageURL + '&cb=' + randNum(); 
		}
		else if(whichAdTag == 13) {
		//altitude $3
			var newVAST = 'http://ssp.lkqd.net/ad?pid=109&sid=40352&env=2&format=2&width=720&height=480&dnt=0&output=vast&rnd=' + randNum() + '&aid=' + appGuid + '&appstoreurl=' + encodeURIComponent(apps[sameApp][4]) + '&appname='+ encodeURIComponent(apps[sameApp][1]) + '&bundleid=' + apps[sameApp][0] + '&ua=' + sameUserAgent; 
		}
	return (newVAST);
	
}